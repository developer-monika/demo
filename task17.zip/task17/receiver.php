<?php
// if ($_SERVER['REQUEST_METHOD'] == 'POST') {
//  	# code...
	// echo "$_POST";
 // 	$data = json_decode(JSON.stringify(model_data));
	// var_dump($data);
 // }  ?>
 <?php 
 // 	$data = json_decode(file_get_contents('frm'), true);
	// print_r($data);
	// echo $data["operacion"];
		 // $json = file_get_contents('http://localhost/rohit/json/senderJson.php'); 
 		//  $obj = json_encode($json);
 // 		//  echo "$obj";
	header("Content-Type: application/json; charset=UTF-8");
	$obj = json_decode($_POST["x"], false);
	echo json_encode($obj);
	// print_r($obj);
	
?>