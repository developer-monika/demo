<html>
	<head>
		<title>Json Sender</title>
		<script src="jquery-1.8.2.min.js" type="text/javascript"></script>
<!-- 		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script> -->
		 <script >
			function sendForm(){
				var   xmlhttp, x, txt = "";
				var fname = $("#fname").val();
		 		var lname = $("#lname").val();
				var email = $("#email").val();
		 		var contact = $("#contact").val();
		 		var data ={"firstname":fname,"lastname":lname,"email":email,"contact":contact};
				var dataString = JSON.stringify(data);
				 xmlhttp = new XMLHttpRequest();
				xmlhttp.onreadystatechange = function() {
    				if (this.readyState == 4 && this.status == 200) {
    				// console.log(this.responseText);
        			document.getElementById("demo").innerHTML = this.responseText;
    				}
				};

				xmlhttp.open("post","receiver.php", true);
				
				xmlhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

				xmlhttp.send("x="+dataString);	
				console.log(dataString);
			}
		

		</script>
	</head>
	<body>
	
		<center>
			<fieldset style="width:300;">
				<legend align="center">Form_Reg</legend>
			<!-- 	<form action="" id="frm" method=""> -->
					<label>First Name</label>
					<input type="text" id="fname" name="fn"><br><br>
					<label>Last Name</label>
					<input type="text" id="lname" name="ln"><br><br>
					<label>Email</label>
					<input type="text" id="email" name="em"><br><br>
					<label>Contact No.</label>
					<input type="text" id="contact" name="cn"><br><br>
					<input type="submit" name="su" value="Send" onclick="sendForm();">
				<!-- </form> -->
			</fieldset>
		</center>
		<p id="demo"></p>
		
	</body>	
</html>
<!-- 
		// 	 	$.ajax({
		// 	 	url: 'reciever.php',
		// 	 	type: 'POST',
		// 	 	contentType: 'application/json',
		// 	 	data: {myData:dataString},
		// 	 	dataType: 'json',
		// 	 	success:function(e){
		// 		    // I know, you do not want Ajax, if you callback to page, you can refresh page here
		// 	 	   }
		// 	 	});
		// 		/*var valueJson = JSON.stringify(model_data);
		// 		window.location = "recieverJson.php?x=" + valueJson;*/ -->

