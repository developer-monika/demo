    <!-- Page Content -->
    <div class="container">
    <!-- Marketing Icons Section -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Registration 
                </h1>
            </div>
           <div class="col-lg-5 col-md-offset-3">
            <form class="form-horizontal" role="form" action="" method="POST">
                <h2>Registration Form</h2>
                <div class="form-group">
                    <label for="firstName" class="col-sm-3 control-label">Full Name</label>
                    <div class="col-sm-9">
                        <input type="text" id="firstName" name="fullname" placeholder="Full Name" class="form-control" value="<?php echo set_value('fullname');?>" autofocus>
                        <span class="help-block">Last Name, First Name, eg.: Smith, Harry</span>
                        <span class="color"><?php echo form_error("fullname") ?></span>
                        </div>
                </div>
                <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-9">
                        <input type="email" name="email" id="email" placeholder="Email" class="form-control" value="<?php echo set_value('email'); ?>">
                         <span class="color"><?php echo form_error("email") ?></span>
                    </div>
                </div>
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input type="password" name="password" id="password" placeholder="Password" class="form-control" value="<?php echo set_value('password');?>">
                        <span class="color"><?php echo form_error("password") ?></span>
                    </div>
                </div>
                 <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Re-Password</label>
                    <div class="col-sm-9">
                        <input type="password" name="repass" id="repass" placeholder="Re-Password" class="form-control" value="<?php echo set_value('repass');?>">
                        <span class="color"><?php echo form_error("repass") ?></span>
                    </div>
                </div>
                <div class="form-group">
                    <label for="city" class="col-sm-3 control-label">City</label>
                    <div class="col-sm-9">
                        <select id="" class="form-control" name="city" value="">
                            <option value="">Select</option>
                            <option <?php echo set_select("city", "indore");?> value="indore">Indore</option>
                            <option <?php echo set_select("city", "bhopal");?> value="bhopal">Bhopal</option>
                            <option <?php echo set_select("city", "ujjain");?> value="ujjain">Ujjain</option>
                        </select>
                        <span class="color"><?php echo form_error("city") ?></span>
                    </div>
                </div> <!-- /.form-group -->
                <div class="form-group">
                    <label for="Contact" class="col-sm-3 control-label">Contact</label>
                    <div class="col-sm-9">
                        <input type="text" name="contact" id="" placeholder="Contact" class="form-control" value="<?php echo set_value('contact');?>">
                        <span class="color"><?php echo form_error("contact") ?></span>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-3">Gender</label>
                    <div class="col-sm-6">
                        <div class="row">
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" <?php echo set_radio("gender", "Female"); ?> name="gender" id="" value="Female">Female
                                </label>
                            </div>
                            <div class="col-sm-4">
                                <label class="radio-inline">
                                    <input type="radio" <?php echo set_radio("gender", "Male"); ?> name="gender" id="" value="Male">Male
                                </label>
                            </div>

                       </div>
                       <span><?php echo form_error("gender")?></span>
                    </div>
                </div> <!-- /.form-group -->
                <!-- <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <div class="checkbox">
                            <label>
                                <input type="checkbox">I accept <a href="#">terms</a>
                            </label>
                        </div>
                    </div>
                </div>--> <!-- /.form-group -->
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <button type="submit" class="btn btn-primary btn-block">Register</button>
                    </div>
                </div>
            </form> <!-- /form -->
        </div>
        </div>
        <!-- /.row -->
        <hr>
        <!-- Call to Action Section -->
        <div class="well">
            <div class="row">
                <div class="col-md-8">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, expedita, saepe, vero rerum deleniti beatae veniam harum neque nemo praesentium cum alias asperiores commodi.</p>
                </div>
                <div class="col-md-4">
                    <a class="btn btn-lg btn-default btn-block" href="#">Call to Action</a>
                </div>
            </div>
        </div>
        <hr>