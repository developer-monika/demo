<div class="container" style="padding-top: 60px;">
  <h1 class="page-header">Edit Profile</h1>
  <?php
        $data=$info->row_array();
        // print_r($data);
        // die;
        ?>
  <div class="row">
    <!-- left column -->
    <div class="col-md-4 col-sm-6 col-xs-12">
      <div class="text-center">
        <?php if($data['image']=="")
        {
          $path=base_url("images/avatar.png");
        }
        else
        {

        $path=base_url("images/".$data['image']);
        }
        ?>
        <img src="<?php echo $path;?>" height="100" />
        <h6>Upload a different photo...</h6>
        
        <!--code-->
       
        <form action="<?php echo site_url('user/image_upload');?>" method="post" enctype="multipart/form-data">
          Select File <input type="file" class="text-center center-block well well-sm" name="userfile" />
          <Br />
          <input type="submit"  value="Upload" />
          
        </form>
        <?php
        echo $this->session->flashdata("msg");
        ?>
        <!--code-->
      </div>
    </div>
    <!-- edit form column -->
    <div class="col-md-8 col-sm-6 col-xs-12 personal-info">
      <div class="alert alert-info alert-dismissable">
        <a class="panel-close close" data-dismiss="alert">×</a> 
        <i class="fa fa-coffee"></i>
        Welcome <strong><?php echo $data['fullname'];?></strong>. update your profile info here.
      </div>
      <h3>Personal info</h3>
      <!-- <form class="form-horizontal" role="form" method="post" action="<?php echo base_url();?>index.php/user/edit_profile">
        <div class="form-group">
          <label class="col-lg-3 control-label">Fullname:</label>
          <div class="col-lg-8">
            <input name="fullname" class="form-control" value="<?php echo $data['fullname'];?>" type="text">
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label">Email:</label>
          <div class="col-lg-8">
            <input class="form-control" name="email" value="<?php echo $data['email'];?>" type="text" disabled="disabled">
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label">City:</label>
          <div class="col-lg-8">
            <select name='city'>
              <option>Select</option>
              <option <?php if($data['city']=="indore"){ echo "selected='selected'"; } ?>>Indore</option>
              <option <?php if($data['city']=="ujjain"){ echo "selected='selected'"; } ?>>Ujjain</option>
              <option <?php if($data['city']=="bhopal"){ echo "selected='selected'"; } ?>>Bhopal</option>
          </select>
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label">Contact:</label>
          <div class="col-lg-8">
            <input class="form-control" name="contact" value="<?php echo $data['contact'];?>" type="text">
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label">Gender:</label>
          <div class="col-lg-8">
          Male  <input type="radio" <?php if($data['gender']=="Male"){ echo "checked='checked'"; } ?> value="Male" name="gender"> &nbsp;&nbsp;
          Female  <input type="radio" <?php if($data['gender']=="Female"){ echo "checked='checked'"; } ?> value="Female" name="gender">
          </div>
        </div>
        <div class="form-group">
          <label class="col-md-3 control-label"></label>
          <div class="col-md-8">
            <input class="btn btn-primary" name="submit"  value="Update" type="submit">
            </div>
        </div>
      </form> -->
    </div>
  </div>
</div>