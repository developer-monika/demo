<div class="container" style="padding-top: 60px;">
  <h1 class="page-header">Profile</h1>
   <?php
        $data=$info->row_array();
   ?>
  <div class="row">
    <!-- left column -->
    <div class="col-md-4 col-sm-6 col-xs-12">
      <div class="text-center">
        <div class="text-center">
        <?php if($data['image']=="")
        {
          $path=base_url("images/avatar.png");
        }
        else
        {

        $path=base_url("images/".$data['image']);
        }
        ?>
        <img src="<?php echo $path;?>" height="100" />
        <h6>Upload a different photo...</h6>
        
        <!--code-->
       
        <form action="<?php echo site_url('user/image_upload');?>" method="post" enctype="multipart/form-data">
          Select File <input type="file" class="text-center center-block well well-sm" name="userfile" />
          <Br />
          <input type="submit"  value="Upload" />
          
        </form>
        <?php
        echo $this->session->flashdata("msg");
        ?>
        <!--code-->
      </div></div>
    </div>
    <!-- edit form column -->
    <div class="col-md-8 col-sm-6 col-xs-12 personal-info">
      <div class="alert alert-info alert-dismissable">
        <a class="panel-close close" data-dismiss="alert">×</a> 
        <i class="fa fa-coffee"></i>
        Welcome <strong><?php echo $data['fullname'];?></strong>. see your profile info here.
      </div>
      <h3>Personal info</h3>
     
      <form class="form-horizontal" role="form">
        <div class="form-group">
          <label class="col-lg-3 control-label">First name:</label>
          <div class="col-lg-8">
           <pre><?php echo $data['fullname'];?></pre>
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label">Email:</label>
          <div class="col-lg-8">
           <pre><?php echo $data['email']; ?></pre>
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label">City:</label>
          <div class="col-lg-8">
            <pre><?php echo $data['city'];?></pre>
            </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label">Contact:</label>
          <div class="col-lg-8">
            <pre><?php echo $data['contact'];?></pre>
          </div>
        </div>
        <div class="form-group">
          <label class="col-lg-3 control-label">Gender:</label>
          <div class="col-lg-8">
            <pre><?php echo $data['gender'];?></pre>
          </div>
        </div>
        <div class="form-group">
       <a href="<?php echo site_url('user/edit_profile');?>">Edit Profile</a>
        </div>
      </form>
    </div>
  </div>
</div>