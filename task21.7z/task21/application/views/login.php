    <style type="text/css">
        .error{
            color: red;
        }
    </style>
    <!-- Page Content -->
    <div class="container">
    <!-- Marketing Icons Section -->
        <div class="row">
            <div class="col-lg-12">
                <h1 class="page-header">
                    Login 
                </h1>
            </div>
           <div class="col-lg-5 col-md-offset-3">
            <form class="form-horizontal" role="form" action="" method="POST">
                <h2>Login Form</h2>
               
                <div class="form-group">
                    <label for="email" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-9">
                        <input type="email" name="email" id="email" placeholder="Email" class="form-control" value="">
                    </div>
                </div>
                <div class="form-group">
                    <label for="password" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-9">
                        <input type="password" name="password" id="password" placeholder="Password" class="form-control" value="">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                        <input type="submit" name="submit" class="btn btn-primary btn-block" value="Login">
                    </div>
                </div>
            </form> <!-- /form -->
            <?php
                echo "<p class='error'>".$this->session->flashdata("msg")."</p>";
            ?>
        </div>
        </div>
        <!-- /.row -->
        <hr>
        <!-- Call to Action Section -->
        <div class="well">
            <div class="row">
                <div class="col-md-8">
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestias, expedita, saepe, vero rerum deleniti beatae veniam harum neque nemo praesentium cum alias asperiores commodi.</p>
                </div>
                <div class="col-md-4">
                    <a class="btn btn-lg btn-default btn-block" href="#">Call to Action</a>
                </div>
            </div>
        </div>
        <hr>