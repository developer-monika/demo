<?php
class User extends CI_Controller{

	function __construct()
	{
		parent::__construct();
		$this->load->helper("url");
		$this->load->library("session");
		$this->load->model("usermod");
		$this->backdoor();
	}
	function backdoor()
	{
		if(! $this->session->userdata("is_user_logged_in"))
		{	
			redirect("home");
		}
	}
	function index()
	{
		$id=$this->session->userdata("id");
		$obj=$this->usermod->select_user($id);
		$data['info']=$obj;
		$data['pagename']="user/profile";
		$data['title']="TSS Profile Page";
		$this->load->view("user/user_layout", $data);
	}
	function upload_pic()
	{
		$id=$this->session->userdata("id");
		$obj=$this->usermod->select_user($id);
		$data['info']=$obj;
		$data['pagename']="user/upload_pic";
		$data['title']="TSS Profile Page";
		$this->load->view("user/user_layout", $data);
	}
	function edit_profile()
	{
		$id=$this->session->userdata("id");
		if($this->input->post("submit"))
		{
			$arr=(array)$this->input->post();
			// print_r($arr);
			unset($arr['submit']);
			$this->usermod->update($id, $arr);
			redirect("user");
		}



		
		$obj=$this->usermod->select_user($id);
		$data['info']=$obj;
		$data['pagename']="user/edit_profile";
		$data['title']="TSS Profile Page";
		$this->load->view("user/user_layout", $data);
	}
	function logout()
	{
		$this->session->sess_destroy();
		redirect("home");
	}
	function image_upload()
	{
		$config['allowed_types']="jpg|png|jpeg|gif";
		$config['max_size']=1024;
		$config['upload_path']="user_images/";
		$config['encrypt_name']=true;
		$this->load->library("upload", $config);
		if($this->upload->do_upload()==false)
		{
			$x= $this->upload->display_errors();
			$this->session->set_flashdata("msg", $x);
			redirect("user/upload_pic");
		}
		else
		{
			$file=$this->upload->data();
			$name=$file['file_name'];
			$arr['image']=$name;
			$id=$this->session->userdata("id");
			$this->usermod->update($id, $arr);
			redirect("user");
			// print_r($file);
		}
	}
}
?>