<?php

class Cpanel extends CI_Controller{

	function __construct()
	{
		parent::__construct();
		$this->load->helper("url");
		$this->load->library("session");
	}


	function backdoor()
	{
		if(! $this->session->userdata("is_admin_logged_in"))
		{
			redirect("home");
		}
	}
	function index()
	{
		$this->load->model("usermod");
		$obj=$this->usermod->get_all();
		
		$data['info']=$obj;
		$data['pagename']="admin/dash";
		$data['title']="TSS Admin Page";
		$this->load->view("admin/admin_layout", $data);
		
	}
	function logout()
	{
		//echo date('Y-m-d h:i:s'); //2017-03-17 05:30:47
		//die;
		$arr['last_login']=date('Y-m-d h:i:s');
		$this->load->model("adminmod");
		$this->adminmod->update(1, $arr);

		$this->session->sess_destroy();
		// UPDATE abmin_tbl SET date=now() WHERE id=1
		redirect("home");
	}
	
	function change($id, $a)
	{
		if($a==1)
			$arr['status']=0;
		if($a==0)
			$arr['status']=1;
		$this->load->model("usermod");
		$this->usermod->update($id, $arr);
		redirect("cpanel");
	}
}
	

?>