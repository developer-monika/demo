<?php

class Admin extends CI_Controller{

	function __construct()
	{
		parent::__construct();
		$this->load->helper("url");
		$this->load->library("session");
	}



	function index()
	{
		if($this->input->post("submit"))
		{
			$u=$this->input->post("email");
			$p=$this->input->post("password");
			$this->load->model("adminmod");
			$obj=$this->adminmod->user_auth($u);
			if($obj->num_rows()==1)
			{
				// echo "yes";
				$data=$obj->row_array();
				// print_r($data);
				if($data['password']==$p)
				{
					$current_date=date('Y-m-d h:i:s');
					$last_login=$data['last_login'];
					$a=date_create($current_date);
					$b=date_create($last_login);
					$i=date_diff($a, $b);
					$x= $i->format('%d Days %h Hours %i Minute Ago');
					// die;

					$this->session->set_userdata("last_login_time", $x);
					$this->session->set_userdata("is_admin_logged_in", true);
					redirect("cpanel");
				}
				else
				{
					$this->session->set_flashdata("msg", "This password is incorrect !");
					redirect("admin");		
				}
			}
			else
			{
				$this->session->set_flashdata("msg", "This username and password is incorrect !");
				redirect("admin");
			}
		}
		$data['pagename']="admin/login";
		$data['title']="TSS Admin Page";
		$this->load->view("admin/layout", $data);
		
	}
}
	

?>