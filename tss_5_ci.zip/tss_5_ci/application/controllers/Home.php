<?php

class Home extends CI_Controller{

	function __construct()
	{
		parent::__construct();
		$this->load->helper("url");
		$this->load->library("session");
	}



	function index()
	{
		$data['pagename']="homepage";
		$data['title']="TSS Home Page";
		$this->load->view("layout", $data);
		
	}
	function about()
	{
		$data['pagename']="about";
		$data['title']="About Page";
		$this->load->view("layout", $data);
	}
	function contact()
	{
		$data['pagename']="contact";
		$data['title']="Contact Page";
		$this->load->view("layout", $data);
	}
	function login()
	{
		if($this->input->post("submit"))
		{
			$u=$this->input->post("email");
			$p=$this->input->post("password");
			$this->load->model("usermod");
			$obj=$this->usermod->user_auth($u);
			if($obj->num_rows()==1)
			{
				// echo "yes";
				$data=$obj->row_array();
				// print_r($data);
				if($data['password']==md5($p))
				{
					if($data['status']==1)
					{
						$this->session->set_userdata("id", $data['id']);
						$this->session->set_userdata("name", $data['full_name']);
						$this->session->set_userdata("is_user_logged_in", true);
						redirect("user");
						
					}
					else
					{
						$this->session->set_flashdata("msg", "You are disable now !");
						redirect("home/login");	
					}
				}
				else
				{
					$this->session->set_flashdata("msg", "This password is incorrect !");
					redirect("home/login");		
				}
			}
			else
			{
				$this->session->set_flashdata("msg", "This username and password is incorrect !");
				redirect("home/login");
			}
		}

		$data['pagename']="login";
		$data['title']="Login Page";
		$this->load->view("layout", $data);
	}
	function signup()
	{
		$this->load->library("form_validation");
		$this->form_validation->set_rules("full_name", "Full Name", "required");
		$this->form_validation->set_rules("email", "Email", "required|valid_email");
		$this->form_validation->set_rules("password", "Password", "required");
		$this->form_validation->set_rules("re_pass", "Re-Password", "required|matches[password]");
		$this->form_validation->set_rules("contact", "Contact", "required|numeric|exact_length[10]");
		$this->form_validation->set_rules("address", "Address", "required");
		$this->form_validation->set_rules("gender", "Gender", "required");
		$this->form_validation->set_rules("city", "City", "required");
		if($this->form_validation->run()==false)
		{
			$data['pagename']="signup";
			$data['title']="Signup Page";
			$this->load->view("layout", $data);
		}
		else
		{
			// print_r($this->input->post());
			// $arr['full_name']=$this->input->post("full_name");
			// $arr['email']=$this->input->post("email");
			// $arr['password']=$this->input->post("pass");
			// $arr['contact']=$this->input->post("contact");
			// $arr['address']=$this->input->post("add");
			// $arr['gender']=$this->input->post("gender");
			// $arr['city']=$this->input->post("city");
			$arr=(array)$this->input->post();
			unset($arr['re_pass']);
			unset($arr['submit']);
			$arr['password']=md5($arr['password']);
			// print_r($arr);die;
			$this->load->model("usermod");
			$this->usermod->add_new($arr);
			redirect("home/login");
		}
	}
}

?>