<?php
class Adminmod extends CI_Model{

	function __construct()
	{
		parent::__construct();
		$this->load->database();
		
	}

	
	function user_auth($a)
	{
		$this->db->where("username", $a);
		$obj=$this->db->get("admin_tbl");
		return $obj;
	}
	function update($id, $arr)
	{
		$this->db->where("id", $id);
		$this->db->update("admin_tbl", $arr);
	}
	
}
?>