<?php
class Usermod extends CI_Model{

	function __construct()
	{
		parent::__construct();
		$this->load->database();
		
	}

	function add_new($arr)
	{
		$this->db->insert("user_tbl", $arr);
	}
	function user_auth($a)
	{
		$this->db->where("email", $a);
		$obj=$this->db->get("user_tbl");
		return $obj;
	}
	function select_user($id)
	{
		$this->db->where("id", $id);
		$obj=$this->db->get("user_tbl");
		return $obj;
	}
	function update($id, $arr)
	{
		$this->db->where("id", $id);
		$this->db->update("user_tbl", $arr);

		
	}
	function get_all()
	{
		$obj=$this->db->get("user_tbl");
		return $obj;
	}
}
?>