<style type="text/css">
	.error{
		height: 20px !important;
		color: red;
		font-size: 13px;
		text-align: left !important;
	}
</style>
	<div id="page" style="min-height: 400px; height: auto;">
		<!-- <div id="content" style="min-height: 400px; height: auto;"> -->
		<div style="min-height: 400px; height: auto; margin: 0 auto; width: 800px; text-align: center;">
				<?php
				//echo validation_errors();
				?>
				<h2>Signup</h2>
				<Hr />
				<form action="" method="post">
	                <table align="center" id="tab">
	                    <tr>
	                        <td>Full Name</td>
	                        <td><input type="text" value="<?php echo set_value('full_name');?>" name="full_name" /></td>
	                    </tr>
	                    <tr class="error">
	                    	<td></td>
	                    	<td><?php echo form_error("full_name") ?></td>
	                    </tr>

	                    <tr>
	                        <td>Email</td>
	                        <td><input type="text" value="<?php echo set_value('email');?>"  name="email"/></td>
	                    </tr>
	                    <tr class="error">
	                    	<td></td>
	                    	<td><?php echo form_error("email") ?></td>
	                    </tr>
	                    <tr>
	                        <td>Password</td>
	                        <td><input type="password"  name="password"/></td>
	                    </tr>
	                    <tr class="error">
	                    	<td></td>
	                    	<td><?php echo form_error("password") ?></td>
	                    </tr>
	                    <tr>
	                        <td>Re-Password</td>
	                        <td><input type="password"  name="re_pass"/></td>
	                    </tr>
	                    <tr class="error">
	                    	<td></td>
	                    	<td><?php echo form_error("re_pass") ?></td>
	                    </tr>
	                    
	                    <tr>
	                        <td>Contact No.</td>
	                        <td><input type="text" value="<?php echo set_value('contact');?>"  name="contact"/></td>
	                    </tr>
	                    <tr class="error">
	                    	<td></td>
	                    	<td><?php echo form_error("contact") ?></td>
	                    </tr>
	                    <tr>
	                        <td>Address</td>
	                        <td><textarea name="address"><?php echo set_value('address');?></textarea></td>
	                    </tr>
	                    <tr class="error">
	                    	<td></td>
	                    	<td><?php echo form_error("address") ?></td>
	                    </tr>
	                    <tr>
	                        <td>Gender</td>
	                        <td>M<input type="radio" <?php echo set_radio("gender", "male"); ?> name="gender" value="male" />
	                            F<input <?php echo set_radio("gender", "female");?> type="radio" name="gender" value="female" /></td>
	                    </tr>
	                    <tr class="error">
	                    	<td></td>
	                    	<td><?php echo form_error("gender") ?></td>
	                    </tr>
	                    <tr>
	                    	<td>City</td>
	                    	<td><select name="city">
	                    			<option value="">Select</option>
	                    			<option <?php echo set_select("city", "indore");?> value="indore">Indore</option>
	                    			<option <?php echo set_select("city", "bhopal");?> value="bhopal">Bhopal</option>
	                    			<option <?php echo set_select("city", "ujjain");?> value="ujjain">Ujjain</option>
	                    		</select></td>
	                    </tr>
	                    <tr class="error">
	                    	<td></td>
	                    	<td><?php echo form_error("city") ?></td>
	                    </tr>
	                    <tr>
	                        <td colspan="2" align="center">
	                            <input type="submit" name="submit" value="Signup" class="btn"/>
	                        </td>
	                    </tr>
	                </table>
			</form>
				
		</div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	<!-- end #page -->
</div>
