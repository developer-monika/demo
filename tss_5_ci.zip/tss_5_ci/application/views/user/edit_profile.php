
	<div id="page" style="min-height: 400px; height: auto;">
		<!-- <div id="content" style="min-height: 400px; height: auto;"> -->
		<div style="min-height: 400px; height: auto; margin: 0 auto; width: 800px; text-align: center;">
			<h2>Welcome :<?php echo $this->session->userdata("name");?></h2>
			<h3>Edit Your Profile</h3>
			<Hr />
				<?php
				$data=$info->row_array();
				// print_r($data);
				
				?>
				<form action="" method="post">
					Full Name <input type="text" name="full_name" value="<?php echo $data['full_name']; ?>">
					<Br />
					<Br />
					Email <input type="text" value="<?php echo $data['email']; ?>" disabled="disabled">
					<Br />
					<Br />
					Contact <input type="text" name="contact" value="<?php echo $data['contact']; ?>" >
					<Br />
					<Br />
					Address<textarea><?php echo $data['address'];?></textarea>
					<Br />
					<Br />
					Gender : M<input type="radio" <?php if($data['gender']=="male"){ echo "checked='checked'"; } ?> value="male" name="gender">
							F<input type="radio" <?php if($data['gender']=="female"){ echo "checked='checked'"; } ?> value="female" name="gender">
					<br />
					<br />
					<br />
					City <select name='city'>
							<option>Select</option>
							<option <?php if($data['city']=="indore"){ echo "selected='selected'"; } ?>>Indore</option>
							<option <?php if($data['city']=="ujjain"){ echo "selected='selected'"; } ?>>Ujjain</option>
							<option <?php if($data['city']=="bhopal"){ echo "selected='selected'"; } ?>>Bhopal</option>
					</select>
					<Br />
					<br />
					<input type="submit" name="submit" value="Update">
					
				</form>
		</div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	<!-- end #page -->
</div>
