
	<div id="page" style="min-height: 400px; height: auto;">
		<!-- <div id="content" style="min-height: 400px; height: auto;"> -->
		<div style="min-height: 400px; height: auto; margin: 0 auto; width: 800px; text-align: center;">
			<h2>Welcome :<?php echo $this->session->userdata("name");?></h2>
			<Hr />
				<?php
				$data=$info->row_array();
				?>
				<h2>Upload Your Profile Pic</h2>
				<form action="<?php echo site_url('user/image_upload');?>" method="post" enctype="multipart/form-data">
					Select File <input type="file" name="userfile" />
					<Br />
					<input type="submit" value="Upload" />
					
				</form>
				<?php
				echo $this->session->flashdata("msg");
				?>
		</div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	<!-- end #page -->
</div>
