
	<div id="page" style="min-height: 400px; height: auto;">
		<!-- <div id="content" style="min-height: 400px; height: auto;"> -->
		<div style="min-height: 400px; height: auto; margin: 0 auto; width: 800px; text-align: center;">
			<h2>Welcome :<?php echo $this->session->userdata("name");?></h2>
			<Hr />
				<?php
				$data=$info->row_array();
				// print_r($data);
				echo "Full Name :".$data['full_name'];
				echo "<Br />";
				echo "Email :".$data['email'];
				echo "<Br />";
				echo "Address :".$data['address'];
				echo "<Br />";
				echo "Gender :".$data['gender'];
				echo "<Br />";
				echo "Contact :".$data['contact'];
				echo "<Br />";
				echo "City :".$data['city'];
				echo "<Br />";
				if($data['image']=="")
				{
					$path=base_url("images/avatar.png");
				}
				else
				{

				$path=base_url("user_images/".$data['image']);
				}
				?>
				<img src="<?php echo $path;?>" height="100" />
		</div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	<!-- end #page -->
</div>
