<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $title;?></title>
<link href="<?php echo base_url('css/style.css'); ?>" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo base_url('js/jquery_new.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('js/jquery.dropotron-1.0.js');?>"></script>
</head>
<body>
<div id="wrapper">
	<div id="header-wrapper">
		<div id="header">
			<div id="logo">
				<h1><a href="#">Commercial</a></h1>
				<p>Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a></p>
			</div>
		</div>
	</div>
	<!-- end #header -->
	<div id="menu-wrapper">
		<ul id="menu">
			<li class="current_page_item"><a href="<?php echo site_url('home/index'); ?>"><span>Homepage</span></a></li>
			<li><a href="<?php echo site_url('home/contact'); ?>"><span>Contact</span></a></li>
			<li><a href="<?php echo site_url('home/about'); ?>"><span>About</span></a></li>
			<li><a href="<?php echo site_url('home/login'); ?>"><span>Login</span></a></li>
			<li><a href="<?php echo site_url('home/signup'); ?>"><span>Signup</span></a></li>
			<!-- <li><span>Blog</span>
				<ul>
					<li class="first"> <a href="index">Maecenas luctus lectus</a> </li>
					<li> <a href="search">Integer gravida</a> </li>
					<li class="last"> <a href="about">Ut nonummy rutrum</a> </li>
				</ul>
			</li> -->
			<!-- <li><span>Links</span>
				<ul>
					<li class="first"> <a href="index">Maecenas luctus lectus</a> </li>
					<li> <a href="search">Integer gravida</a> </li>
					<li class="last"> <a href="about">Ut nonummy rutrum</a> </li>
				</ul>
			</li> -->
		</ul>
		<script type="text/javascript">
			$('#menu').dropotron();
		</script>
	</div>
	<!-- end #menu -->
	<div id="splash"><img src="<?php echo base_url('images/pics01.jpg'); ?>" width="980" height="300" alt="" /></div>

<?php
$this->load->view($pagename);
?>



<div id="footer">
	<p>2012. Untitled. All rights reserved. Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>. Photos by <a href="http://fotogrph.com/">fotogrph</a>.</p>
</div>
<!-- end #footer -->
</body>
</html>
