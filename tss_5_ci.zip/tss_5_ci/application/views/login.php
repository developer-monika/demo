
	<div id="page" style="min-height: 400px; height: auto;">
		<!-- <div id="content" style="min-height: 400px; height: auto;"> -->
		<div style="min-height: 400px; height: auto; margin: 0 auto; width: 800px; text-align: center;">
			<h2>Login Page</h2>
			<Hr />
						<form action="" method="post">
			                <table align="center" id="tab">
			                    <tr>
			                        <td>Email</td>
			                        <td><input type="text" name="email"/></td>
			                    </tr>
			                    <tr>
			                        <td>Password</td>
			                        <td><input type="password" name="password"/></td>
			                    </tr>
			                   
			                    <tr>
			                        <td colspan="2" align="center">
			                            <input type="submit" name="submit" value="Login" class="btn"/>
			                        </td>
			                    </tr>
			                </table>
					</form>
				<?php
				echo "<p class='error'>".$this->session->flashdata("msg")."</p>";
				?>
		</div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	<!-- end #page -->
</div>
