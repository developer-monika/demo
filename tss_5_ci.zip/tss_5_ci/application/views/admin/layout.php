<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title><?php echo $title;?></title>
<link href="<?php echo base_url('css/style.css'); ?>" rel="stylesheet" type="text/css" media="screen" />
<script type="text/javascript" src="<?php echo base_url('js/jquery_new.js');?>"></script>
<script type="text/javascript" src="<?php echo base_url('js/jquery.dropotron-1.0.js');?>"></script>
</head>
<body>
<div id="wrapper">
<?php
$this->load->view($pagename);
?>



<div id="footer">
	<p>2012. Untitled. All rights reserved. Design by <a href="http://templated.co" rel="nofollow">TEMPLATED</a>. Photos by <a href="http://fotogrph.com/">fotogrph</a>.</p>
</div>
<!-- end #footer -->
</body>
</html>
