
	<div id="page" style="min-height: 600px; height: auto;">
		<!-- <div id="content" style="min-height: 400px; height: auto;"> -->
		<div style="min-height: 400px; height: auto; margin: 0 auto; width: 800px; text-align: center;">
		<hr />
		<table width="90%" border="1">
			<tr>
				<th>#</th>
				<th>Full Name</th>
				<th>Email</th>
				<th>Contact</th>
				<th>Status</th>
				<th>Change</th>
			</tr>
			<?php
			$n=1;
			foreach($info->result_array() as $data)
			{?>
				<tr>
					<td><?php echo $n;?></td>
					<td><?php echo $data['full_name'];?></td>
					<td><?php echo $data['email'];?></td>
					<td><?php echo $data['contact'];?></td>
					<?php
					if($data['status']==1)
					{

						echo '<td>Enable</td>';
					}
					else
					{
						echo '<td>Disable</td>';

					}
					?>
					<td><a href="<?php echo site_url('cpanel/change/'.$data['id'].'/'.$data['status']); ?>">Change</a></td>
				</tr>
			<?php
			$n++;
			 }
			?>
		</table>
		<hr />
			
		</div>
		<!-- end #sidebar -->
		<div style="clear: both;">&nbsp;</div>
	</div>
	<!-- end #page -->
</div>
