<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<br/>
<br/>
<form action="upload.php" method="post" enctype="multipart/form-data">

    <input type="file" name="image" />
    <input type="submit" value="Upload" />
</form>
</body>
<br/>
<br/>
</body>
</html>