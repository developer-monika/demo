<?php
$con=mysql_connect("localhost", "root","");
mysql_select_db("fileupload", $con);
//$con = mysqli_connect('localhost','root','','fileupload');
session_start();
?>

